<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Gerenciar Favoritos</name>
   <tag></tag>
   <elementGuidId>7cdcfe53-37d3-4b2c-86c2-ccc2ffeb5407</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div/div[2]/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h4.m-a-0.text-lg._300</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Gerenciar Favoritos&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>c01f1b9c-f4aa-4c4b-8d95-e09c6e9665b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>m-a-0 text-lg _300</value>
      <webElementGuid>54dc2b30-e402-4f53-8a12-925049289d67</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        Gerenciar Favoritos
                    </value>
      <webElementGuid>900c2f78-b61e-4f67-a45e-3e699948d427</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;clear&quot;]/h4[@class=&quot;m-a-0 text-lg _300&quot;]</value>
      <webElementGuid>1a9ada96-1ccb-4e65-82f9-a357a6aa7ece</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div/div[2]/h4</value>
      <webElementGuid>bfeee4fd-30f5-4dfa-adcc-5b6571f53f73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQ'])[1]/following::h4[1]</value>
      <webElementGuid>1a6c5c7f-e577-42a0-b229-19f0b37e5ff7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INFORMES'])[1]/following::h4[1]</value>
      <webElementGuid>279c8cc0-5a6b-4cfd-b95b-5fd599cba560</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total de 4 favoritos.'])[1]/preceding::h4[1]</value>
      <webElementGuid>9ebd1148-256c-494c-b8f8-e4ffe93f6cd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Gerenciar Favoritos']/parent::*</value>
      <webElementGuid>3dac5c0c-252b-41e6-ba18-d2f97d378d96</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h4</value>
      <webElementGuid>d12c6677-9245-479d-8ff9-0edd69bcafa1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = '
                        Gerenciar Favoritos
                    ' or . = '
                        Gerenciar Favoritos
                    ')]</value>
      <webElementGuid>0a6fb9ce-c8d2-4335-8421-f98c0a067b52</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
