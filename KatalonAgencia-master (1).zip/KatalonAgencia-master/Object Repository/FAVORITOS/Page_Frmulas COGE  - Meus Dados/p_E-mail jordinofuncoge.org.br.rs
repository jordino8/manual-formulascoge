<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_E-mail jordinofuncoge.org.br</name>
   <tag></tag>
   <elementGuidId>19235359-4472-45d0-9980-bcea9503b7ed</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div[3]/div/div/div/p[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;E-mail: jordino@funcoge.org.br&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>ec97e0d0-c5df-4621-aeda-79ca58b350c4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                E-mail: jordino@funcoge.org.br
                            </value>
      <webElementGuid>debe9451-67fb-48f1-b7fa-a1f54a0dd7a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-6&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;clear&quot;]/p[2]</value>
      <webElementGuid>3c655351-e598-406d-aa98-33957c42fb34</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div[3]/div/div/div/p[2]</value>
      <webElementGuid>efdb35d2-d032-45b1-8d62-00d8ebd63284</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Empresa'])[1]/following::p[1]</value>
      <webElementGuid>ec135c32-02fe-4457-b987-aec7909e819d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alterar Dados de Perfil'])[1]/following::p[2]</value>
      <webElementGuid>7bc12238-0156-4983-a24a-8977a9db8440</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='E-mail Confirmado'])[1]/preceding::p[1]</value>
      <webElementGuid>503236e1-6a47-40a1-a86a-dc111985f835</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)=': jordino@funcoge.org.br']/parent::*</value>
      <webElementGuid>69b9f04d-3ce9-41c5-a04f-d935e8f6130e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[2]</value>
      <webElementGuid>1d4bdfd0-a7b3-48a0-baf0-254ca1cf241b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
                                E-mail: jordino@funcoge.org.br
                            ' or . = '
                                E-mail: jordino@funcoge.org.br
                            ')]</value>
      <webElementGuid>e0aaf505-c3bd-48e1-af31-7f0b662ad86b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
