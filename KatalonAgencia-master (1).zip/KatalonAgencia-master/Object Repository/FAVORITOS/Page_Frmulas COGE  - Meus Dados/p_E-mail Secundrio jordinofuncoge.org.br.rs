<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_E-mail Secundrio jordinofuncoge.org.br</name>
   <tag></tag>
   <elementGuidId>ac51f885-51ed-46c7-b5d0-1ab21a372214</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div[3]/div[2]/div/div/p[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;E-mail Secundário: jordino@funcoge.org.br&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>e440c141-e7c4-4c65-8be1-afeb36518593</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                E-mail Secundário: jordino@funcoge.org.br
                            </value>
      <webElementGuid>1ffac8c7-c399-4204-9ec4-6caf20d7d158</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-6&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;clear&quot;]/p[4]</value>
      <webElementGuid>b17e0f4f-fb36-4e84-8529-b5580fa6500f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div[3]/div[2]/div/div/p[4]</value>
      <webElementGuid>688d9546-9416-4e02-be61-8ab527bf9235</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nome Completo'])[1]/following::p[1]</value>
      <webElementGuid>eed25e9a-2b61-49ca-bc4d-b1d9df738100</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SIM'])[3]/following::p[2]</value>
      <webElementGuid>5ae18786-6802-462c-98a1-5ebd1edb7814</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/p[4]</value>
      <webElementGuid>18cfcab8-6ee1-4b54-ad74-64b5fc306319</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
                                E-mail Secundário: jordino@funcoge.org.br
                            ' or . = '
                                E-mail Secundário: jordino@funcoge.org.br
                            ')]</value>
      <webElementGuid>8b4638e9-0517-440e-af9e-10c9841664fb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
