<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Dados de Perfil                        _1d813d</name>
   <tag></tag>
   <elementGuidId>a64d6837-a0c1-463b-8ac2-fe838a6a9ca4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div[3]/div[2]/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Dados de Perfil Inativo: NÃO Aceita Divulgações?: SIM Nome Completo: Jordino Per&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>752d7ad2-8df4-49ec-95f6-e6b7df5e981f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>clear</value>
      <webElementGuid>ced4da18-9fd2-4cc6-a210-619b7c8c34b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            
                                Dados de Perfil
                            
                            
                            
                                Inativo:
                                    NÃO
                            
                            
                                Aceita Divulgações?:
                                    SIM                             
                            
                                Nome Completo: Jordino Pereira
                            
                            
                                E-mail Secundário: jordino@funcoge.org.br
                            
                        </value>
      <webElementGuid>c7d70c79-72b7-4cdb-ab16-9e88c5e6dfc6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-6&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;clear&quot;]</value>
      <webElementGuid>c12944e8-3f4c-489e-ba15-63438a75daab</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div[3]/div[2]/div/div</value>
      <webElementGuid>f8fc8bf4-e6d7-4ff8-b5f6-3d0fdfc4afb3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SIM'])[2]/following::div[3]</value>
      <webElementGuid>fb70efa8-1ecf-47d3-8e86-65cfb9ddccb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Somente Favoritos'])[1]/following::div[3]</value>
      <webElementGuid>f11eba3f-1414-456f-a679-cda73c4116f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/div/div/div[3]/div[2]/div/div</value>
      <webElementGuid>2d3775b5-a1cf-439d-a306-efbfe4b5a139</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                            
                                Dados de Perfil
                            
                            
                            
                                Inativo:
                                    NÃO
                            
                            
                                Aceita Divulgações?:
                                    SIM                             
                            
                                Nome Completo: Jordino Pereira
                            
                            
                                E-mail Secundário: jordino@funcoge.org.br
                            
                        ' or . = '
                            
                                Dados de Perfil
                            
                            
                            
                                Inativo:
                                    NÃO
                            
                            
                                Aceita Divulgações?:
                                    SIM                             
                            
                                Nome Completo: Jordino Pereira
                            
                            
                                E-mail Secundário: jordino@funcoge.org.br
                            
                        ')]</value>
      <webElementGuid>4c898801-d9dd-4884-b2dd-d55931f97e72</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
