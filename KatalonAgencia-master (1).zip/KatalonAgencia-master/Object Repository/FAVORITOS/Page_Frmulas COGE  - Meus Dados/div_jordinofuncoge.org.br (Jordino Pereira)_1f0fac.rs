<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_jordinofuncoge.org.br (Jordino Pereira)_1f0fac</name>
   <tag></tag>
   <elementGuidId>5aa5dbf8-3f0a-4163-9384-5fb106d1cafa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.box.p-a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>.box >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>a2b60439-f1a9-416b-81f5-a7a3baba2d17</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>box p-a</value>
      <webElementGuid>6f5b1e75-bf61-4e1d-92ec-8b7071dc20a9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                
                
                    
                        jordino@funcoge.org.br (Jordino Pereira)
                    
                    * Os seus dados de perfil podem ser modificados, basta clicar no menu de contexto ao lado.
                
            </value>
      <webElementGuid>5b96c36c-dc11-481b-b47c-8a73450ac136</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;box p-a&quot;]</value>
      <webElementGuid>00a603a2-fd47-4cb7-87d4-81c91088a263</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div</value>
      <webElementGuid>45877cad-d3f3-4053-9d87-948fb6e8e4d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQ'])[1]/following::div[10]</value>
      <webElementGuid>506b9ac0-5fd9-4ab9-bfaf-403fc2dc6c05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INFORMES'])[1]/following::div[10]</value>
      <webElementGuid>7e0d1c31-ed4c-4860-ad61-f1af19455a52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/div/div/div</value>
      <webElementGuid>dc0c12c3-96a6-4f8e-9e05-364923b63890</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                    
                
                
                    
                        jordino@funcoge.org.br (Jordino Pereira)
                    
                    * Os seus dados de perfil podem ser modificados, basta clicar no menu de contexto ao lado.
                
            ' or . = '
                
                    
                
                
                    
                        jordino@funcoge.org.br (Jordino Pereira)
                    
                    * Os seus dados de perfil podem ser modificados, basta clicar no menu de contexto ao lado.
                
            ')]</value>
      <webElementGuid>b545fe89-b7df-47f3-a2a7-92ee5fbab389</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
