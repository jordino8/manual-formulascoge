<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Meus Acessos</name>
   <tag></tag>
   <elementGuidId>1fcfff7f-3a9a-4cd0-85cd-08519a74d453</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div[2]/div/div[2]/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-xs-12.col-sm-12 > div.box.p-a > div.clear > h4.m-a-0.text-lg._300</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Meus Acessos&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>003d2f35-46ae-4b44-a0fc-f7f659c5db77</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>m-a-0 text-lg _300</value>
      <webElementGuid>7ce16982-f6e4-45c0-a3ad-4ed0aeea443b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Meus Acessos</value>
      <webElementGuid>ed1e62cb-0d68-462d-8083-9434e559acc1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 col-sm-12&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;clear&quot;]/h4[@class=&quot;m-a-0 text-lg _300&quot;]</value>
      <webElementGuid>ba12d8b5-d6b3-4ff4-bd24-1f88c1e16b6a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div[2]/div/div[2]/h4</value>
      <webElementGuid>afb8ba4a-4fdb-42aa-b06d-2b126c7e3f66</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='jordino@funcoge.org.br'])[1]/following::h4[1]</value>
      <webElementGuid>86c86828-5628-4117-b7d0-abc7960a3c4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='E-mail Secundário'])[1]/following::h4[1]</value>
      <webElementGuid>9c7d1802-8cfd-451e-8a09-2dee4daacd60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tipos de recursos que estou habilitado a acessar.'])[1]/preceding::h4[1]</value>
      <webElementGuid>d0b4e7c3-8aca-4b16-9219-504a75b662cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Acesso Fundação COGE - Estatísticas COGE'])[1]/preceding::h4[1]</value>
      <webElementGuid>eca87fc6-0084-44b5-9d4c-547aad14954f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Meus Acessos']/parent::*</value>
      <webElementGuid>b0b96539-0833-421a-a38d-5dcc31f70dd0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/h4</value>
      <webElementGuid>2788de5c-0caa-4715-be45-e99fd4f13936</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Meus Acessos' or . = 'Meus Acessos')]</value>
      <webElementGuid>a4cf0603-cc5b-488c-9396-e79485f96745</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
