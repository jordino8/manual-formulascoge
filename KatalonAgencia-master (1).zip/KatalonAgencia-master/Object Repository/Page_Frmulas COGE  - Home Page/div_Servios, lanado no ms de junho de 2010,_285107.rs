<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Servios, lanado no ms de junho de 2010,_285107</name>
   <tag></tag>
   <elementGuidId>2bb09954-8a78-4558-ba2c-8f2445013ace</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div[2]/div/div[3]/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>.col-xs-12 > div:nth-child(3)</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>77957ef6-2641-4f29-975e-22634f1168bf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-xs-6</value>
      <webElementGuid>0680788e-f742-4357-9eae-836bb4a285f3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            
                                Serviços, lançado no mês de junho de 2010, é composto por
131                                Fórmulas alimentadas por indicadores fornecidos
                                pela FGV através de contrato específico com a Fundação COGE.
                            
                            
                                Estas fórmulas são uma importante ferramenta de mercado para atualização de preços dos serviços utilizados pelo Setor Elétrico-Energético Nacional
                                e somente poderão ser acessadas pelos contratantes do acesso ao sistema, que vem recebendo atualizações e aperfeiçoamentos frequentes.
                            
                            
                                
                            
                        </value>
      <webElementGuid>f49fe551-5352-48be-8dc1-dd288bb9acbd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-6&quot;]</value>
      <webElementGuid>6c05070e-9fb4-4ff7-95ec-1822e96878db</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div[2]/div/div[3]/div[2]</value>
      <webElementGuid>64a3a9fa-c181-40ea-9cc1-d0a785c797d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='®'])[2]/following::div[3]</value>
      <webElementGuid>a09549a7-ac28-465d-acdc-5e31c6330943</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fórmulas COGE ® - Home Page'])[2]/following::div[7]</value>
      <webElementGuid>fec32a4d-c7be-40a5-92dc-918519c6dad1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Como Assinar'])[1]/preceding::div[1]</value>
      <webElementGuid>085db6a5-f631-457a-881c-134de3b226c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='®'])[3]/preceding::div[1]</value>
      <webElementGuid>8534da9d-3b90-4ed5-86ea-409a94a47ac4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[3]/div[2]</value>
      <webElementGuid>0f4ff36f-e289-43dd-8a53-0eb4ceec0ce5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                            
                                Serviços, lançado no mês de junho de 2010, é composto por
131                                Fórmulas alimentadas por indicadores fornecidos
                                pela FGV através de contrato específico com a Fundação COGE.
                            
                            
                                Estas fórmulas são uma importante ferramenta de mercado para atualização de preços dos serviços utilizados pelo Setor Elétrico-Energético Nacional
                                e somente poderão ser acessadas pelos contratantes do acesso ao sistema, que vem recebendo atualizações e aperfeiçoamentos frequentes.
                            
                            
                                
                            
                        ' or . = '
                            
                                Serviços, lançado no mês de junho de 2010, é composto por
131                                Fórmulas alimentadas por indicadores fornecidos
                                pela FGV através de contrato específico com a Fundação COGE.
                            
                            
                                Estas fórmulas são uma importante ferramenta de mercado para atualização de preços dos serviços utilizados pelo Setor Elétrico-Energético Nacional
                                e somente poderão ser acessadas pelos contratantes do acesso ao sistema, que vem recebendo atualizações e aperfeiçoamentos frequentes.
                            
                            
                                
                            
                        ')]</value>
      <webElementGuid>8d82aefb-0c0a-4b98-93c6-21fe4f1dc48a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
