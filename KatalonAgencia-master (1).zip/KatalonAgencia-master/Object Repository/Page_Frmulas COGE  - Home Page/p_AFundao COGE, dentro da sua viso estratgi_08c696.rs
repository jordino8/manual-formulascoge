<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_AFundao COGE, dentro da sua viso estratgi_08c696</name>
   <tag></tag>
   <elementGuidId>461115b6-6ef2-4494-8f5e-bb3add1785f9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div[2]/div/div[2]/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;A Fundação COGE, dentro da sua visão estratégica de apoiar as empresas do Setor &quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>6cfe396b-1de5-484d-8449-b29085dcfaf9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            A Fundação COGE, dentro da sua visão estratégica de apoiar as empresas do Setor Elétrico-Energético Nacional, criou e mantém o sistema Fórmulas COGE ®.
                        </value>
      <webElementGuid>080f01f5-05bd-40f3-9e8f-e4159188d066</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;col-xs-12&quot;]/p[1]</value>
      <webElementGuid>ae37cba0-e8a6-4ad9-b8af-5a4d3967cefa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div[2]/div/div[2]/p</value>
      <webElementGuid>2f572d3b-7894-4527-981a-ec5b5b152a90</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fórmulas COGE ® - Home Page'])[2]/following::p[1]</value>
      <webElementGuid>109a4fba-d81e-447f-be52-48eb7c8e12a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQ'])[1]/following::p[1]</value>
      <webElementGuid>288da284-eaba-4329-b0ae-8676417af5ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='®'])[2]/preceding::p[1]</value>
      <webElementGuid>249b8857-e2ba-47b1-98aa-70d0be7d2a82</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Como Assinar'])[1]/preceding::p[8]</value>
      <webElementGuid>993b3f50-ff8f-4a07-aeed-b6fa922aa4ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='A Fundação COGE, dentro da sua visão estratégica de apoiar as empresas do Setor Elétrico-Energético Nacional, criou e mantém o sistema Fórmulas COGE ®.']/parent::*</value>
      <webElementGuid>cacb78b9-43dc-457e-b4b6-bd15ec46a785</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p</value>
      <webElementGuid>8aef8ca7-5de1-41d9-83f6-0d9b14a96739</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
                            A Fundação COGE, dentro da sua visão estratégica de apoiar as empresas do Setor Elétrico-Energético Nacional, criou e mantém o sistema Fórmulas COGE ®.
                        ' or . = '
                            A Fundação COGE, dentro da sua visão estratégica de apoiar as empresas do Setor Elétrico-Energético Nacional, criou e mantém o sistema Fórmulas COGE ®.
                        ')]</value>
      <webElementGuid>b698888f-9e86-43c0-a1ef-647e2734e4c1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
