<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Frmulas MateriaisServios.  Perodo 010120_1d151c</name>
   <tag></tag>
   <elementGuidId>abef24ce-8eb7-4585-9f1e-a9346e0f8f7a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div[3]/div/div/h2</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Fórmulas: Materiais/Serviços. | Período: 01/01/2020 - 01/05/2024.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>c272a61b-1520-41bc-95b6-eaa9b44b8bc5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Fórmulas: Materiais/Serviços. | Período: 01/01/2020 - 01/05/2024.</value>
      <webElementGuid>2dac5d38-d46c-4dc3-a6f6-6a0a56b54bda</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;box-header&quot;]/h2[1]</value>
      <webElementGuid>f608ea4e-33be-4cfc-a596-3ab287edd642</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div[3]/div/div/h2</value>
      <webElementGuid>0105c6b1-9aaa-4781-92f8-d7c2669cd35f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Exportação - Variações por Período das Fórmulas COGE'])[1]/following::h2[1]</value>
      <webElementGuid>d9e56ab3-c38e-420b-af24-05e984c40bae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tabela de Resultados'])[1]/preceding::h2[1]</value>
      <webElementGuid>d18b63b7-d6a9-4e3f-99c0-f6448e375e85</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Código'])[1]/preceding::h2[1]</value>
      <webElementGuid>cb18cb37-360b-467f-bad9-39988d877ea5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Fórmulas: Materiais/Serviços. | Período: 01/01/2020 - 01/05/2024.']/parent::*</value>
      <webElementGuid>4a444786-bad7-4acb-9528-558b57b93cfe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>85307776-3fa9-44d4-94f1-d7e42ead9631</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Fórmulas: Materiais/Serviços. | Período: 01/01/2020 - 01/05/2024.' or . = 'Fórmulas: Materiais/Serviços. | Período: 01/01/2020 - 01/05/2024.')]</value>
      <webElementGuid>235eb3b5-080b-4386-84e3-bd35c5bbbcf8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
