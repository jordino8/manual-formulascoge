<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Exportao - Variaes por Perodo das Frmulas COGE</name>
   <tag></tag>
   <elementGuidId>74820e3c-a5e6-4a76-b309-738305a7038c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div/div[2]/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h4.m-a-0.text-lg._300</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Exportação - Variações por Período das Fórmulas COGE&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>8b6c29d5-7024-4bf4-811c-b7a09c6ea4bb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>m-a-0 text-lg _300</value>
      <webElementGuid>5a86db6c-f710-4fdf-beb3-5f468421ad01</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        Exportação - Variações por Período das Fórmulas COGE
                    </value>
      <webElementGuid>7b2c79c8-3eda-4faf-8cdb-b6d7a6f32959</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;clear&quot;]/h4[@class=&quot;m-a-0 text-lg _300&quot;]</value>
      <webElementGuid>272496fa-f6fb-45e8-a4b6-a4d861710dad</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div/div[2]/h4</value>
      <webElementGuid>ad15fedb-290a-4fa5-a411-a568fc64f801</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQ'])[1]/following::h4[1]</value>
      <webElementGuid>eae93a67-cc77-4031-8867-4fcb95f5f92e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INFORMES'])[1]/following::h4[1]</value>
      <webElementGuid>90979e2d-2758-4399-b0d8-a182b5f721ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fórmulas: Materiais/Serviços. | Período: 01/01/2020 - 01/05/2024.'])[1]/preceding::h4[1]</value>
      <webElementGuid>74312d43-0717-42e7-87fe-555d61e55e53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Exportação - Variações por Período das Fórmulas COGE']/parent::*</value>
      <webElementGuid>6eb89db8-43cd-4c7d-9bf7-3c16ca89f1c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h4</value>
      <webElementGuid>d562002a-75ae-410c-9cde-a610d88d7499</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = '
                        Exportação - Variações por Período das Fórmulas COGE
                    ' or . = '
                        Exportação - Variações por Período das Fórmulas COGE
                    ')]</value>
      <webElementGuid>ee076072-1964-4477-844c-6dd59a58c396</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
