<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Ocorreu um erro inesperado</name>
   <tag></tag>
   <elementGuidId>5bd7126c-3e63-4840-9761-e74877b51598</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div/div[2]/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h4.m-a-0.text-lg._300</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Ocorreu um erro inesperado.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>72f79399-ecdb-4f81-8f8b-f0e4edf438aa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>m-a-0 text-lg _300</value>
      <webElementGuid>aebd9016-deb7-4f5c-9d97-271091502f0c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    Ocorreu um erro inesperado.
                </value>
      <webElementGuid>573ede70-dbe9-453f-a7f9-78b990a013d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;clear&quot;]/h4[@class=&quot;m-a-0 text-lg _300&quot;]</value>
      <webElementGuid>4c132f53-11ab-4a6f-846b-fbeb8631e801</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div/div[2]/h4</value>
      <webElementGuid>82359a24-2118-430f-a117-a81b83fd04f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQ'])[1]/following::h4[1]</value>
      <webElementGuid>2d04cdfd-2128-40ef-935c-f79beb47edaa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INFORMES'])[1]/following::h4[1]</value>
      <webElementGuid>17d5d46b-536a-4f68-bcd0-43a5d70e3fc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Por favor tente novamente mais tarde.'])[1]/preceding::h4[1]</value>
      <webElementGuid>70007ead-272f-4223-aa1f-0e713cb85675</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Última atualização dos indicadores:'])[1]/preceding::h4[1]</value>
      <webElementGuid>0bee81ee-6289-4d12-93c0-17491f62ddb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Ocorreu um erro inesperado.']/parent::*</value>
      <webElementGuid>2e685799-0e4d-40db-9ab7-270f51add126</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h4</value>
      <webElementGuid>6e546c01-1f10-4be7-b4f0-be90502e69f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = '
                    Ocorreu um erro inesperado.
                ' or . = '
                    Ocorreu um erro inesperado.
                ')]</value>
      <webElementGuid>0be82bfb-81d8-4b86-9740-0e19a65f8982</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
