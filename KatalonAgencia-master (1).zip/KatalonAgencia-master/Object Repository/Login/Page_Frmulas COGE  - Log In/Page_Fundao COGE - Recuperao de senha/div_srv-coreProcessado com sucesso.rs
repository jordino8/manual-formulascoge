<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_srv-coreProcessado com sucesso</name>
   <tag></tag>
   <elementGuidId>76a96bbb-c759-4b0a-9b67-86946605d7f6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::div[6]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.toast__content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;srv-coreProcessado com sucesso!&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>830db965-08fe-4793-9d88-a3432aa15e26</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>toast__content</value>
      <webElementGuid>bf88b0b3-91fc-468d-9a5d-707d6018fbdd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>srv-coreProcessado com sucesso!</value>
      <webElementGuid>9669a80b-cde9-40e1-ab3b-84497354eb79</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;history svg video supports boxshadow csstransforms3d csstransitions backgroundcliptext webkit chrome win js sticky-header-mobile-disabled&quot;]/body[1]/div[@class=&quot;body&quot;]/div[@class=&quot;toast__container&quot;]/div[@class=&quot;toast__cell&quot;]/div[1]/div[@class=&quot;toast toast--green&quot;]/div[@class=&quot;toast__content&quot;]</value>
      <webElementGuid>01d02dc4-ee3a-4f39-b852-33e4f9955cc2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::div[6]</value>
      <webElementGuid>a65ef762-a889-4f9c-b016-531c2220afa3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQ'])[1]/following::div[6]</value>
      <webElementGuid>0caae8e1-d5e5-4bc3-bbad-bef15d662d45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RECUPERAÇÃO DE SENHA'])[1]/preceding::div[4]</value>
      <webElementGuid>ca42d7db-7f54-4c30-a4ed-3d9caeadbe70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div[2]</value>
      <webElementGuid>26af8c6f-ea2e-429b-974d-861aab59a0a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'srv-coreProcessado com sucesso!' or . = 'srv-coreProcessado com sucesso!')]</value>
      <webElementGuid>b42effc5-af7d-4bda-85ee-c4320742590c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
