<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_AAC - AramesdeAoaoCarbono</name>
   <tag></tag>
   <elementGuidId>00a10abc-ec1f-4876-9a90-57ebc81d59c3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.col-xs-12 > h4.m-a-0.text-lg._300</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div[3]/div/div/div/div/h4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;AAC - Arames de Aço ao Carbono&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>7ca1a673-3986-4ae8-a1b8-d66a781d5528</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>m-a-0 text-lg _300</value>
      <webElementGuid>3fb071dd-62ed-416c-a354-a6cf90d1a801</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                AAC - Arames de Aço ao Carbono
                            </value>
      <webElementGuid>bc36d0bd-315e-43f0-b1d6-493bb9637bc4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 col-sm-12&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;clear&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-12&quot;]/h4[@class=&quot;m-a-0 text-lg _300&quot;]</value>
      <webElementGuid>431aec96-889a-4fda-ba7b-0c965233f657</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div[3]/div/div/div/div/h4</value>
      <webElementGuid>ed209ac5-64f7-42c1-b933-87319faeb994</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Token: b997629b-c939-4fa3-a128-f040b6b27eca'])[1]/following::h4[1]</value>
      <webElementGuid>a09ce526-5b1b-4510-b36f-1455ab24977d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Detalhes'])[1]/preceding::h4[1]</value>
      <webElementGuid>dde4f8ad-101b-4e48-83c5-afc1f1aca359</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Período Selecionado'])[1]/preceding::h4[1]</value>
      <webElementGuid>95202597-943f-4be8-bd63-7af178db1122</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='AAC - Arames de Aço ao Carbono']/parent::*</value>
      <webElementGuid>644cf9b8-cb7e-4a1b-943c-da773b6b20d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/h4</value>
      <webElementGuid>88fc1d25-f0d3-40a1-8721-b5851b6723bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = '
                                AAC - Arames de Aço ao Carbono
                            ' or . = '
                                AAC - Arames de Aço ao Carbono
                            ')]</value>
      <webElementGuid>0ca0c1c4-6f14-4fea-a451-5a57a5922fe2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
