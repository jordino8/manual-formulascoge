<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_O Sistema Frmulas COGE , cuja patente foi_ae1049</name>
   <tag></tag>
   <elementGuidId>5b7309e5-d152-4030-910d-bf3ea63e73ce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div[2]/div/div[2]/p[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;O Sistema Fórmulas COGE ®, cuja patente foi registrada em nome da Fundação COGE,&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>070360f3-c17e-4036-9791-751d169a0639</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            O Sistema Fórmulas COGE ®, cuja patente foi registrada em nome da Fundação COGE, compreende 2 subprodutos:
                        </value>
      <webElementGuid>17136cb2-4dc3-4d93-8d36-7a4788877738</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;col-xs-12&quot;]/p[2]</value>
      <webElementGuid>8fb2670a-a63c-45f4-b45e-839e113118a9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div[2]/div/div[2]/p[2]</value>
      <webElementGuid>42d37d17-aef3-4192-a48f-85f02eb31d7d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fórmulas COGE ® - Home Page'])[2]/following::p[2]</value>
      <webElementGuid>46e8166e-a5d1-4c3d-9b33-9c918a8e969f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQ'])[1]/following::p[2]</value>
      <webElementGuid>3b0e356e-4cd9-4ae3-8c8a-9e828d26b6dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Como Assinar'])[1]/preceding::p[7]</value>
      <webElementGuid>7b1f1a17-769a-4cd4-8f8f-fad23fffe8df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='O Sistema Fórmulas COGE']/parent::*</value>
      <webElementGuid>c8362b99-26b6-463e-9b41-09ccf6e31d42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[2]</value>
      <webElementGuid>2c98d2be-84d1-4599-a956-3d8211dd3fc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
                            O Sistema Fórmulas COGE ®, cuja patente foi registrada em nome da Fundação COGE, compreende 2 subprodutos:
                        ' or . = '
                            O Sistema Fórmulas COGE ®, cuja patente foi registrada em nome da Fundação COGE, compreende 2 subprodutos:
                        ')]</value>
      <webElementGuid>b6e2bf1d-1850-4c6a-af38-1c631323cf24</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
