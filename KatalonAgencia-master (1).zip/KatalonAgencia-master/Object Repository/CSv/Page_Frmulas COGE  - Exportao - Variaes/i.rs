<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i</name>
   <tag></tag>
   <elementGuidId>f2e96ebd-12c3-49a1-a449-b26ab113f11d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>/html/body/div[2]/div/div[2]/div/div/div[2]/div/div[1]/div[3]/form/div/div[2]/div[1]/div/div[3]/label[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;loadingForm&quot;)/div[@class=&quot;box&quot;]/div[@class=&quot;box-body&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-6&quot;]/div[@class=&quot;form-group col-xs-12&quot;]/label[@class=&quot;ui-switch green m-t-xs m-r&quot;]/i[1][count(. | //input&#xd;
[@aria-hidden = 'true' and @value = 'Csv']) = count(//input&#xd;
[@aria-hidden = 'true' and @value = 'Csv'])]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>    -webkit-text-size-adjust: 100%;&#xd;
    -webkit-tap-highlight-color: transparent;&#xd;
    --coge-app-color: #8c008c !important;&#xd;
    --coge-font-family: &quot;Roboto&quot;,&quot;Helvetica Neue&quot;,Helvetica,Arial,sans-serif;&#xd;
    -webkit-font-smoothing: antialiased;&#xd;
    font: inherit;&#xd;
    overflow: visible;&#xd;
    touch-action: manipulation;&#xd;
    margin: 0;&#xd;
    line-height: inherit;&#xd;
    border-radius: 0;&#xd;
    box-sizing: border-box;&#xd;
    padding: 0;&#xd;
    position: absolute;&#xd;
    opacity: 0;</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>i >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>input&#xd;
</value>
      <webElementGuid>b262b9e2-d953-45dc-80aa-2c45fa5d613a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>ba97ea51-990f-44de-a30b-85e007a4ba82</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;loadingForm&quot;)/div[@class=&quot;box&quot;]/div[@class=&quot;box-body&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-6&quot;]/div[@class=&quot;form-group col-xs-12&quot;]/label[@class=&quot;ui-switch green m-t-xs m-r&quot;]/i[1]</value>
      <webElementGuid>7245915f-298a-4305-bb97-1943c9fdf0e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>value</name>
      <type>Main</type>
      <value>Csv</value>
      <webElementGuid>5ee91ada-9fce-46d1-8a0e-449992a4e575</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='loadingForm']/div/div[2]/div/div/div[3]/label[2]/i</value>
      <webElementGuid>dda8aadf-e2b7-4dbd-b743-ed2b0c3d8170</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/label[2]/i</value>
      <webElementGuid>fbe227ed-11a0-4478-a7af-470b37325ec7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
