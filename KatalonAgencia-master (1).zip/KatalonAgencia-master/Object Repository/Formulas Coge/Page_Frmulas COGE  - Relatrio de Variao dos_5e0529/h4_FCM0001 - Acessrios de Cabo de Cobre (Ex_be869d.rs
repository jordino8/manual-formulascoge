<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_FCM0001 - Acessrios de Cabo de Cobre (Ex_be869d</name>
   <tag></tag>
   <elementGuidId>9bee81b8-5920-482e-abbf-17f6100805ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div[3]/div/div/div/div/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-xs-12 > h4.m-a-0.text-lg._300</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;FCM0001 - Acessórios de Cabo de Cobre (Exceto os Materiais com Fórmula Própria)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>85f2c117-b780-425b-af2e-52cc6ee20037</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>m-a-0 text-lg _300</value>
      <webElementGuid>d1a68ca1-3bdb-40d5-a6f0-677544581a2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                FCM0001 - Acessórios de Cabo de Cobre (Exceto os Materiais com Fórmula Própria)
                            </value>
      <webElementGuid>46679e03-39e6-4f0d-bd78-d7c73dc63735</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 col-sm-12&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;clear&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-12&quot;]/h4[@class=&quot;m-a-0 text-lg _300&quot;]</value>
      <webElementGuid>b1f16921-3dcb-429b-8be8-7e1ae4cd0cdf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div[3]/div/div/div/div/h4</value>
      <webElementGuid>75d60fe4-a4fc-459c-a58e-9c76267ce18e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Token: 3a1deecf-4987-43a5-94a4-d04523391d58'])[1]/following::h4[1]</value>
      <webElementGuid>b82acc60-0167-4bca-8217-d135ee6ff55f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Detalhes'])[1]/preceding::h4[1]</value>
      <webElementGuid>fecfd8fd-c5a8-48e1-97da-fa375aabf655</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Período Selecionado'])[1]/preceding::h4[1]</value>
      <webElementGuid>1b4b765a-3942-4d8c-892f-d7c64e20dd6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='FCM0001 - Acessórios de Cabo de Cobre (Exceto os Materiais com Fórmula Própria)']/parent::*</value>
      <webElementGuid>175fc68f-f09f-424e-945c-033a0880e684</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/h4</value>
      <webElementGuid>7b2d8c5a-233e-44ac-acfe-ce8416488a5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = '
                                FCM0001 - Acessórios de Cabo de Cobre (Exceto os Materiais com Fórmula Própria)
                            ' or . = '
                                FCM0001 - Acessórios de Cabo de Cobre (Exceto os Materiais com Fórmula Própria)
                            ')]</value>
      <webElementGuid>eeea0be1-216e-4c73-a5e4-0d85fb6c05f4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
