<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Frmulas Paramtricas</name>
   <tag></tag>
   <elementGuidId>ee4c1443-d6cc-4595-af11-ba8bf1ea0376</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/div/div/ul/li[2]/div/span[5]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span:nth-of-type(5) > a.dropdown-item</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; Fórmulas Paramétricas&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>edd96f74-5b9b-40dc-b0be-33114e8127d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/exportacoes/formulas-parametricas</value>
      <webElementGuid>9fb0dd80-705e-4133-9722-07aac048827d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item</value>
      <webElementGuid>30890794-75e7-4b34-8c63-e55583d5e4bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Fórmulas Paramétricas</value>
      <webElementGuid>40375ac0-9e8a-4dce-82c2-ef87c273a6e1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/div[@class=&quot;app-header navbar-md white box-shadow&quot;]/div[@class=&quot;navbar text-blue-hover&quot;]/ul[@class=&quot;nav navbar-nav pull-right&quot;]/li[@class=&quot;nav-item dropdown open&quot;]/div[@class=&quot;dropdown-menu pull-right dropdown-menu-scale&quot;]/span[5]/a[@class=&quot;dropdown-item&quot;]</value>
      <webElementGuid>4fdc6d13-6166-49a7-93ab-499703000395</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/div/div/ul/li[2]/div/span[5]/a</value>
      <webElementGuid>8d701f47-eb2f-4d66-b127-0cbd62fc3a07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Fórmulas Paramétricas')]</value>
      <webElementGuid>90e8f124-eb71-496a-af06-d8b6bb1c2356</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Exportações'])[1]/following::a[1]</value>
      <webElementGuid>0348eba7-001a-4524-907a-713ef684b78a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Indicadores'])[1]/following::a[1]</value>
      <webElementGuid>3e91c847-5191-454e-9df8-7dfea841f090</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Variações'])[1]/preceding::a[1]</value>
      <webElementGuid>eed83ce5-5bc2-49a3-949a-868897f115aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Favoritos'])[1]/preceding::a[2]</value>
      <webElementGuid>b43d98a2-2dcf-4beb-bea9-88c8df8110fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Fórmulas Paramétricas']/parent::*</value>
      <webElementGuid>d9c40a11-5cc8-4d58-905e-d3a886688e1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/exportacoes/formulas-parametricas')]</value>
      <webElementGuid>10fb38b9-be59-459c-a2df-11c0bacf3db8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[5]/a</value>
      <webElementGuid>35b46dda-f128-4096-afbd-16087a395a63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/exportacoes/formulas-parametricas' and (text() = ' Fórmulas Paramétricas' or . = ' Fórmulas Paramétricas')]</value>
      <webElementGuid>804ac968-5da7-42f9-a108-6db8996548ae</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
