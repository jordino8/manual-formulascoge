<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Tabela de Frmulas Paramtricas          _67f30d</name>
   <tag></tag>
   <elementGuidId>1a3b2983-c598-4d42-92ad-60aba5cc2e88</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div[3]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-xs-12 > div.col-xs-12 > div.box.p-a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div:nth-child(3) > .box</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c5ce0f2b-a648-48a0-8379-4c9b7370c9c5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>box p-a</value>
      <webElementGuid>1ad0121a-506b-4fd1-a85e-bda96d67b4f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                            
                                Tabela de Fórmulas Paramétricas
                                
                                    Nome
                                    Nome da Categoria
                                    Fórmula Paramétrica
                                    Status
                                
                                    
                                        
                                            
                                                    
                                                FCM0006 - Amortecedor Tipo Stockbridge
                                            
                                        
                                        
                                            Acessórios para Cabos
                                        
                                        
                                            R = 0.30000.MO + 0.70000.PMNF
                                        
                                        
                                            Ativo
                                        
                                    
                                    
                                        
                                            
                                                    
                                                FCM0004 - Alça Pré-Formada de Aço Revestida com Alumínio
                                            
                                        
                                        
                                            Ferragens de Linhas de Transmissão e Distribuição
                                        
                                        
                                            R = 0.25000.MO + 0.15000.AL + 0.60000.AT
                                        
                                        
                                            Ativo
                                        
                                    
                                    
                                        
                                            
                                                    
                                                FCM0011 - Bandeja e Suporte para Cabo Sem Projetos
                                            
                                        
                                        
                                            Suportes / Bandejas
                                        
                                        
                                            R = 0.25000.MO + 0.05000.ZN + 0.70000.BAC
                                        
                                        
                                            Ativo
                                        
                                    
                                    
                                        
                                            
                                                    
                                                FCM0003 - Acessórios Não Ferrosos / Latão em Ligas de Cobre (Bronze / Latão)
                                            
                                        
                                        
                                            Ferragens para Linha de Distribuição
                                        
                                        
                                            R = 0.30000.MO + 0.70000.LC
                                        
                                        
                                            Ativo
                                        
                                    
                                    
                                        
                                            
                                                    
                                                FCM0028 - Cabo de Alumínio Protegido Com XLPE para Classe 25 kV
                                            
                                        
                                        
                                            Cabos Cobertos ou Isolados até 34 kV
                                        
                                        
                                            R = 0.16000.MO + 0.34000.AL + 0.50000.PEAD2
                                        
                                        
                                            Ativo
                                        
                                    
                            
                        
                </value>
      <webElementGuid>0cb7a904-b113-4996-adfd-f88a6b4d5bb2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;box p-a&quot;]</value>
      <webElementGuid>79a12d58-259c-48bf-8993-5d12f4f34763</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div[3]/div</value>
      <webElementGuid>dfa7db2f-f06a-4e4f-a2e3-09d5613c7ff1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total de 5 fórmulas registradas.'])[1]/following::div[4]</value>
      <webElementGuid>c0976238-4120-4299-b2da-a22cf27c0091</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/div/div/div[3]/div</value>
      <webElementGuid>a1000cc5-84ec-4c93-ae68-9786d07cfa5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                        
                            
                                Tabela de Fórmulas Paramétricas
                                
                                    Nome
                                    Nome da Categoria
                                    Fórmula Paramétrica
                                    Status
                                
                                    
                                        
                                            
                                                    
                                                FCM0006 - Amortecedor Tipo Stockbridge
                                            
                                        
                                        
                                            Acessórios para Cabos
                                        
                                        
                                            R = 0.30000.MO + 0.70000.PMNF
                                        
                                        
                                            Ativo
                                        
                                    
                                    
                                        
                                            
                                                    
                                                FCM0004 - Alça Pré-Formada de Aço Revestida com Alumínio
                                            
                                        
                                        
                                            Ferragens de Linhas de Transmissão e Distribuição
                                        
                                        
                                            R = 0.25000.MO + 0.15000.AL + 0.60000.AT
                                        
                                        
                                            Ativo
                                        
                                    
                                    
                                        
                                            
                                                    
                                                FCM0011 - Bandeja e Suporte para Cabo Sem Projetos
                                            
                                        
                                        
                                            Suportes / Bandejas
                                        
                                        
                                            R = 0.25000.MO + 0.05000.ZN + 0.70000.BAC
                                        
                                        
                                            Ativo
                                        
                                    
                                    
                                        
                                            
                                                    
                                                FCM0003 - Acessórios Não Ferrosos / Latão em Ligas de Cobre (Bronze / Latão)
                                            
                                        
                                        
                                            Ferragens para Linha de Distribuição
                                        
                                        
                                            R = 0.30000.MO + 0.70000.LC
                                        
                                        
                                            Ativo
                                        
                                    
                                    
                                        
                                            
                                                    
                                                FCM0028 - Cabo de Alumínio Protegido Com XLPE para Classe 25 kV
                                            
                                        
                                        
                                            Cabos Cobertos ou Isolados até 34 kV
                                        
                                        
                                            R = 0.16000.MO + 0.34000.AL + 0.50000.PEAD2
                                        
                                        
                                            Ativo
                                        
                                    
                            
                        
                ' or . = '
                        
                            
                                Tabela de Fórmulas Paramétricas
                                
                                    Nome
                                    Nome da Categoria
                                    Fórmula Paramétrica
                                    Status
                                
                                    
                                        
                                            
                                                    
                                                FCM0006 - Amortecedor Tipo Stockbridge
                                            
                                        
                                        
                                            Acessórios para Cabos
                                        
                                        
                                            R = 0.30000.MO + 0.70000.PMNF
                                        
                                        
                                            Ativo
                                        
                                    
                                    
                                        
                                            
                                                    
                                                FCM0004 - Alça Pré-Formada de Aço Revestida com Alumínio
                                            
                                        
                                        
                                            Ferragens de Linhas de Transmissão e Distribuição
                                        
                                        
                                            R = 0.25000.MO + 0.15000.AL + 0.60000.AT
                                        
                                        
                                            Ativo
                                        
                                    
                                    
                                        
                                            
                                                    
                                                FCM0011 - Bandeja e Suporte para Cabo Sem Projetos
                                            
                                        
                                        
                                            Suportes / Bandejas
                                        
                                        
                                            R = 0.25000.MO + 0.05000.ZN + 0.70000.BAC
                                        
                                        
                                            Ativo
                                        
                                    
                                    
                                        
                                            
                                                    
                                                FCM0003 - Acessórios Não Ferrosos / Latão em Ligas de Cobre (Bronze / Latão)
                                            
                                        
                                        
                                            Ferragens para Linha de Distribuição
                                        
                                        
                                            R = 0.30000.MO + 0.70000.LC
                                        
                                        
                                            Ativo
                                        
                                    
                                    
                                        
                                            
                                                    
                                                FCM0028 - Cabo de Alumínio Protegido Com XLPE para Classe 25 kV
                                            
                                        
                                        
                                            Cabos Cobertos ou Isolados até 34 kV
                                        
                                        
                                            R = 0.16000.MO + 0.34000.AL + 0.50000.PEAD2
                                        
                                        
                                            Ativo
                                        
                                    
                            
                        
                ')]</value>
      <webElementGuid>7c389c20-fcf3-484f-8775-6e6f05a36563</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
