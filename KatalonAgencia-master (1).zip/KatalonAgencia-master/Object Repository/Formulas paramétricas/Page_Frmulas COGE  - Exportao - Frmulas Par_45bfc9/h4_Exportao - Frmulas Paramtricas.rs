<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Exportao - Frmulas Paramtricas</name>
   <tag></tag>
   <elementGuidId>4d589596-b75a-4a91-93ec-109a47abb88a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='view']/div/div/div[2]/div/div/div/div[2]/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h4.m-a-0.text-lg._300</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Exportação - Fórmulas Paramétricas&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>4d83e96e-d495-4955-9076-1955cfadfbe9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>m-a-0 text-lg _300</value>
      <webElementGuid>53818989-d1a4-4656-bcd2-1dec639f9d08</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        Exportação - Fórmulas Paramétricas
                    </value>
      <webElementGuid>b340975c-0b7e-454f-aedc-6e84bbae7c96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;view&quot;)/div[@class=&quot;padding&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 push-md-2 col-md-8&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;box p-a&quot;]/div[@class=&quot;clear&quot;]/h4[@class=&quot;m-a-0 text-lg _300&quot;]</value>
      <webElementGuid>ec857ca9-110a-4b83-8c21-e927c4fd76f5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='view']/div/div/div[2]/div/div/div/div[2]/h4</value>
      <webElementGuid>ae2eca24-f51d-4282-81ef-e4b3471e6d19</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQ'])[1]/following::h4[1]</value>
      <webElementGuid>0e19ec44-7454-4639-b1d8-78f5a594ce33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INFORMES'])[1]/following::h4[1]</value>
      <webElementGuid>2be23b30-2b17-45d4-b111-00c48d57d830</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total de 5 fórmulas registradas.'])[1]/preceding::h4[1]</value>
      <webElementGuid>bced565a-4b25-4bf1-9372-e3685c17f941</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Exportação - Fórmulas Paramétricas']/parent::*</value>
      <webElementGuid>e73eb21c-1e2a-488d-b103-e523f6d6eb46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h4</value>
      <webElementGuid>9eb6541a-d730-4aa0-bfbc-9bfdde329b7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = '
                        Exportação - Fórmulas Paramétricas
                    ' or . = '
                        Exportação - Fórmulas Paramétricas
                    ')]</value>
      <webElementGuid>c76ef216-bf96-44e2-85d0-105d91df0035</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
